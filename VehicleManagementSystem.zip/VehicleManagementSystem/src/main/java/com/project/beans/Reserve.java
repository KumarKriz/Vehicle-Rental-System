package com.project.beans;

import org.json.JSONObject;

public class Reserve {
private int userid;
private int vehicle_id;
private int reservation_id;
private String pickup_loc;
private String drop_loc;
private double start_meter;
private double end_meter;
private int days;
private double advance;
private double amount;
private JSONObject otherproperties;
private  boolean returned;
private double reserve_date;

public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
public int getVehicle_id() {
	return vehicle_id;
}
public void setVehicle_id(int vehicle_id) {
	this.vehicle_id = vehicle_id;
}
public int getReservation_id() {
	return reservation_id;
}
public void setReservation_id(int reservation_id) {
	this.reservation_id = reservation_id;
}
public String getPickup_loc() {
	return pickup_loc;
}
public void setPickup_loc(String pickup_loc) {
	this.pickup_loc = pickup_loc;
}
public String getDrop_loc() {
	return drop_loc;
}
public void setDrop_loc(String drop_loc) {
	this.drop_loc = drop_loc;
}
public double getStart_meter() {
	return start_meter;
}
public void setStart_meter(double start_meter) {
	this.start_meter = start_meter;
}
public double getEnd_meter() {
	return end_meter;
}
public void setEnd_meter(double end_meter) {
	this.end_meter = end_meter;
}
public int getDays() {
	return days;
}
public void setDays(int days) {
	this.days = days;
}
public double getAdvance() {
	return advance;
}
public void setAdvance(double advance) {
	this.advance = advance;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
public JSONObject getOtherproperties() {
	return otherproperties;
}
public void setOtherproperties(JSONObject otherproperties) {
	this.otherproperties = otherproperties;
}
public boolean isReturned() {
	return returned;
}
public void setReturned(boolean returned) {
	this.returned = returned;
}
public double getReserve_date() {
	return reserve_date;
}
public void setReserve_date(double reserve_date) {
	this.reserve_date = reserve_date;
}
}
