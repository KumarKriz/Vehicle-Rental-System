package com.project.beans;

import org.json.JSONObject;

public class Vehicle {
	private int vehicle_id;
	private String vehicle_no;
	private String vehicle_name;
	private String vehicle_model;
	private String vehicle_img;
	private int noof_seats;
	private int rate_perkm;
	private boolean vehicle_booked;
	private JSONObject otherproperties;
	
	public int getVehicle_id() {
		return vehicle_id;
	}
	public void setVehicle_id(int vehicle_id) {
		this.vehicle_id = vehicle_id;
	}
	public String getVehicle_no() {
		return vehicle_no;
	}
	public void setVehicle_no(String vehicle_no) {
		this.vehicle_no = vehicle_no;
	}
	public String getVehicle_name() {
		return vehicle_name;
	}
	public void setVehicle_name(String vehicle_name) {
		this.vehicle_name = vehicle_name;
	}
	public String getVehicle_model() {
		return vehicle_model;
	}
	public void setVehicle_model(String vehicle_model) {
		this.vehicle_model = vehicle_model;
	}
	public String getVehicle_img() {
		return vehicle_img;
	}
	public void setVehicle_img(String vehicle_img) {
		this.vehicle_img = vehicle_img;
	}
	public int getNoof_seats() {
		return noof_seats;
	}
	public void setNoof_seats(int noof_seats) {
		this.noof_seats = noof_seats;
	}
	public int getRate_perkm() {
		return rate_perkm;
	}
	public void setRate_perkm(int rate_perkm) {
		this.rate_perkm = rate_perkm;
	}
	public boolean isVehicle_booked() {
		return vehicle_booked;
	}
	public void setVehicle_booked(boolean vehicle_booked) {
		this.vehicle_booked = vehicle_booked;
	}
	public JSONObject getOtherproperties() {
		return otherproperties;
	}
	public void setOtherproperties(JSONObject otherproperties) {
		this.otherproperties = otherproperties;
	}
}
