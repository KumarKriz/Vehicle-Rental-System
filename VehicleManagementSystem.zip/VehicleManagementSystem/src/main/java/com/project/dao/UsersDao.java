package com.project.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.json.JSONObject;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.project.beans.Reserve;
import com.project.beans.User;
import com.project.beans.Vehicle;

public class UsersDao
{
    JdbcTemplate template;

    public void setTemplate(JdbcTemplate template)
    {
        this.template = template;
    }

    //user
    public int save(String name,
                    String email,
                    String phno,
                    int age,
                    String address,
                    String password,
                    int admin,
                    String otherproperties)
    {
        String sql = "insert into userreg(name,email,phno,age,address,password,admin,otherproperties)values('" + name + "','" + email + "','" + phno + "'," + age + ",'" + address + "','" + password + "','" + admin + "','"+ otherproperties +"')";
        return template.update(sql);
    }

    public User login(String email, String password)
    {
        String sql = "select * from userreg where email=? and password=?";
        return template.queryForObject(sql, new Object[] {email,password}, new BeanPropertyRowMapper<User>(User.class));
    }
    
    
    public User userview(int userid)
    {
        String sql = "select * from userreg where userid=?";
        return template.queryForObject(sql, new Object[] {userid}, new BeanPropertyRowMapper<User>(User.class));
    }
    
    public int edit(int userid,
    		String name,
            String email,
            String phno,
            int age,
            String address,
            String password,
            String otherproperties)
    {
    	String sql= "update userreg set name='"+name+"', email='"+email+"',phno='"+phno+"',age="+age+",address='"+address+"',password='"+password+"',otherproperties='"+otherproperties+"' where userid="+userid;
		return template.update(sql);
    }

    
    
    //vehicle
	public int add(String vehicle_no,
			       String vehicle_name,
			       String vehicle_model,
			       String vehicle_img,
			       int noof_seats,
			       int rate_perkm,
			       int vehicle_booked,
			       String otherproperties)
	{
		String sql="insert into vehicle(vehicle_no,vehicle_name,vehicle_model,vehicle_img,noof_seats,rate_perkm,vehicle_booked,otherproperties)values('"+vehicle_no+"','"+vehicle_name+"','"+vehicle_model+"','"+vehicle_img+"',"+noof_seats+","+rate_perkm+","+vehicle_booked+",'"+otherproperties+"')";
		return template.update(sql);
	}
	public int delete(int vehicle_id)
	{
		String sql="delete from vehicle where vehicle_id = "+vehicle_id;
		return template.update(sql);
	}
	public int edit(int vehicle_id,
			   String vehicle_no,
		       String vehicle_name,
		       String vehicle_model,
		       String vehicle_img,
		       int noof_seats,
		       int rate_perkm,
		       String otherproperties)
	{
		String sql= "update vehicle set vehicle_no='"+vehicle_no+"', vehicle_name='"+vehicle_name+"',vehicle_model='"+vehicle_model+"',vehicle_img='"+vehicle_img+"',noof_seats="+noof_seats+",rate_perkm="+rate_perkm+", otherproperties='"+otherproperties+"' where vehicle_id="+vehicle_id;
		return template.update(sql);
	}
	 
	public int updateBookedVehicle(int vehicle_booked,
			                       int vehicle_id)
	{
		String sql="update vehicle set vehicle_booked="+vehicle_booked+" where vehicle_id="+vehicle_id;
		return template.update(sql);		
	}
	
	public Vehicle view(int vehicle_id)
    {
        String sql = "select * from vehicle where vehicle_id=?";
        return template.queryForObject(sql, new Object[] {vehicle_id}, new BeanPropertyRowMapper<Vehicle>(Vehicle.class));
    }

    public List<Vehicle> viewAll(){  
       return template.query("select * from vehicle",new RowMapper<Vehicle>(){  
         public Vehicle mapRow(ResultSet rs, int row) throws SQLException {  
             Vehicle veh=new Vehicle();  
             veh.setVehicle_id(rs.getInt(1));    
             veh.setVehicle_no(rs.getString(2));  
             veh.setVehicle_name(rs.getString(3));  
             veh.setVehicle_model(rs.getString(4));
             veh.setVehicle_img(rs.getString(5));
             veh.setNoof_seats(rs.getInt(6));
             veh.setRate_perkm(rs.getInt(7));
             veh.setVehicle_booked(rs.getBoolean(8));
             String op=rs.getString(9);
             JSONObject prop=null;
             if(op!=null&&op.length()>0)
             {
            	 prop=new JSONObject(op);
             }
             veh.setOtherproperties(prop);
             return veh;  
        }  
    });  
}  


//reserve
public int make(int userid,
		        int vehicle_id,
		        String pickup_loc,
				String drop_loc,
				double start_meter,
				double end_meter,
				int days,
				double advance,
				double amount,
				String otherproperties,
				int returned,
				double reserve_date)


{
	String sql="insert into reserve(userid,vehicle_id,pickup_loc,drop_loc,start_meter,end_meter,days,advance,amount,otherproperties,returned,reserve_date)values("+userid+","+vehicle_id+",'"+pickup_loc+"','"+drop_loc+"',"+start_meter+","+end_meter+","+days+","+advance+","+amount+",'"+otherproperties+"',"+returned+","+reserve_date+")";
	return template.update(sql);
}

public int remove(int reservation_id)
{
	String sql="delete from reserve where reservation_id = "+reservation_id;
	return template.update(sql);
}
public int update(int reservation_id,
		int vehicle_id,
		String pickup_loc,
		String drop_loc,
		double start_meter,
		double end_meter,
		int days,
		double advance,
		double amount,
		String otherproperties,
		double reserve_date)
{
	String sql= "update reserve set vehicle_id="+vehicle_id+",pickup_loc='"+pickup_loc+"',drop_loc='"+drop_loc+"',start_meter="+start_meter+",end_meter="+end_meter+",days="+days+",advance="+advance+",amount="+amount+",otherproperties='"+otherproperties+",reserve_date="+reserve_date+"' where reservation_id="+reservation_id;
	return template.update(sql);
}

public Reserve resview(int reservation_id)
{
    String sql = "select * from reserve where reservation_id=?";
    return template.queryForObject(sql, new Object[] {reservation_id}, new BeanPropertyRowMapper<Reserve>(Reserve.class));
}

public int returnVehicle(double amount,
		                       int reservation_id,int returned,double start_meter,double end_meter )
{
	String sql="update reserve set amount="+amount+",returned="+returned+",start_meter="+start_meter+",end_meter="+end_meter+" where reservation_id="+reservation_id;
	return template.update(sql);		
}

public List<Reserve> viewResAll(){  
    return template.query("select * from reserve",new RowMapper<Reserve>(){  
      public Reserve mapRow(ResultSet rs, int row) throws SQLException {  
          Reserve veh=new Reserve();  
          veh.setUserid(rs.getInt(1));    
          veh.setVehicle_id(rs.getInt(2));  
          veh.setReservation_id(rs.getInt(3));  
          veh.setPickup_loc(rs.getString(4));
          veh.setDrop_loc(rs.getString(5));
          veh.setStart_meter(rs.getDouble(6));
          veh.setEnd_meter(rs.getDouble(7));
          veh.setDays(rs.getInt(8));
          veh.setAdvance(rs.getDouble(9));
          veh.setAmount(rs.getDouble(10));
          String op=rs.getString(11);
          JSONObject prop=null;
          if(op!=null&&op.length()>0)
          {
         	 prop=new JSONObject(op);
          }
          veh.setOtherproperties(prop);
          veh.setReturned(rs.getBoolean(12));
          veh.setReserve_date(rs.getDouble(13));
          return veh;
          
     }  
 });  
}
public List<Reserve> resUserViewByUserId(int userid){
    return template.query("select * from reserve where userid="+userid,new RowMapper<Reserve>(){  
      public Reserve mapRow(ResultSet rs, int row) throws SQLException {  
          Reserve veh=new Reserve();  
          veh.setUserid(rs.getInt(1));    
          veh.setVehicle_id(rs.getInt(2));  
          veh.setReservation_id(rs.getInt(3));  
          veh.setPickup_loc(rs.getString(4));
          veh.setDrop_loc(rs.getString(5));
          veh.setStart_meter(rs.getDouble(6));
          veh.setEnd_meter(rs.getDouble(7));
          veh.setDays(rs.getInt(8));
          veh.setAdvance(rs.getDouble(9));
          veh.setAmount(rs.getDouble(10));
          String op=rs.getString(11);
          JSONObject prop=null;
          if(op!=null&&op.length()>0)
          {
         	 prop=new JSONObject(op);
          }
          veh.setOtherproperties(prop);
          veh.setReturned(rs.getBoolean(12));
          veh.setReserve_date(rs.getDouble(13));
          return veh;  

      }
    });
}

public List<Reserve> viewReport(long start, long end){  
    return template.query("select * from reserve where reserve_date between "+start+ " and "+end,new RowMapper<Reserve>(){  
      public Reserve mapRow(ResultSet rs, int row) throws SQLException {  
          Reserve veh=new Reserve();  
          veh.setUserid(rs.getInt(1));    
          veh.setVehicle_id(rs.getInt(2));  
          veh.setReservation_id(rs.getInt(3));  
          veh.setPickup_loc(rs.getString(4));
          veh.setDrop_loc(rs.getString(5));
          veh.setStart_meter(rs.getDouble(6));
          veh.setEnd_meter(rs.getDouble(7));
          veh.setDays(rs.getInt(8));
          veh.setAdvance(rs.getDouble(9));
          veh.setAmount(rs.getDouble(10));
          String op=rs.getString(11);
          JSONObject prop=null;
          if(op!=null&&op.length()>0)
          {
         	 prop=new JSONObject(op);
          }
          veh.setOtherproperties(prop);
          veh.setReturned(rs.getBoolean(12));
          veh.setReserve_date(rs.getDouble(13));
          return veh;
          
     }  
 });  
}




}