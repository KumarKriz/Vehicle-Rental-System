package com.project.controller;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.beans.User;
import com.project.beans.Vehicle;
import com.project.dao.UsersDao;

@Controller
public class VehicleController {
	    @Autowired
	    UsersDao dao;
	    @RequestMapping(value = "/vehicle/add", method = RequestMethod.POST)
	    public @ResponseBody
	    String vehicleadd(@RequestParam(value = "vehicle_no") String vehicle_no,
	            @RequestParam(value = "vehicle_name") String vehicle_name,
	            @RequestParam(value = "vehicle_model") String vehicle_model,
	            @RequestParam(value = "vehicle_img",required=false) String vehicle_img,
	            @RequestParam(value = "noof_seats") int noof_seats,
	            @RequestParam(value = "rate_perkm") int rate_perkm,
	            @RequestParam(value = "otherproperties",required=false) String otherproperties) {
	    	JSONObject res=new JSONObject();
	    	try {
	    		String propStr=null;
	        	if(otherproperties.length()>0)
	        	{
	        		propStr=otherproperties.toString();
	        	}
	    		  dao.add(vehicle_no, vehicle_name, vehicle_model, vehicle_img, noof_seats, rate_perkm, 0, propStr);
	              res.put("responsecode", 1);
	              res.put("message", "vehicle added Successfully");
	    	}
	    	catch(Exception e) {
	              res.put("responsecode", 0);
	              res.put("message", "vehicle added failed");
	              System.out.println("failed" + e);
	    	}
			return res.toString();
	    }
	    
	    @RequestMapping(value = "/vehicle/edit", method = RequestMethod.POST)
	    public @ResponseBody
	    String vehicleedit(@RequestParam(value = "vehicle_id") int vehicle_id,
	            @RequestParam(value = "vehicle_no",required=false) String vehicle_no,
	            @RequestParam(value = "vehicle_name",required=false) String vehicle_name,
	            @RequestParam(value = "vehicle_model",required=false) String vehicle_model,
	            @RequestParam(value = "vehicle_img",required=false) String vehicle_img,
	            @RequestParam(value = "noof_seats",required=false) int noof_seats,
	            @RequestParam(value = "rate_perkm",required=false) int rate_perkm,
	            @RequestParam(value = "otherproperties",required=false) String otherproperties) {
	    	JSONObject res = new JSONObject();
	    	try {
	    		String propStr=null;
	        	if(otherproperties.length()>0)
	        	{
	        		propStr=otherproperties.toString();
	        	}
	    		  dao.edit(vehicle_id, vehicle_no, vehicle_name, vehicle_model, vehicle_img, noof_seats, rate_perkm, propStr);
	              res.put("responsecode", 1);
	              res.put("message", "vehicle edited Successfully");
	    	}
	    	catch(Exception e) {
	              res.put("responsecode", 0);
	              res.put("message", "vehicle edited failed");
	              System.out.println("failed" + e);
	    	}
	    	return res.toString();
}
	    @RequestMapping(value = "/vehicle/delete", method = RequestMethod.POST)
	    public @ResponseBody
	    String vehicledelete(@RequestParam(value = "vehicle_id") int vehicle_id) {
	    	JSONObject res = new JSONObject();
	    	try {
	    		  dao.delete(vehicle_id);
	              res.put("responsecode", 1);
	              res.put("message", "vehicle deleted Successfully");
	    	}
	    	catch(Exception e) {
	              res.put("responsecode", 0);
	              res.put("message", "vehicle deleted failed");
	              System.out.println("failed" + e);
	    	}
	    	return res.toString();
	    }
	    
	    @RequestMapping(value = "/vehicle/view", method = RequestMethod.POST)  
	    public @ResponseBody
	    	String vehicleview(@RequestParam(value = "vehicle_id") int vehicle_id) {
	    	JSONObject res = new JSONObject();
	    	try {
	    		Vehicle veh=dao.view(vehicle_id);
	    		res.put("responsecode", 1);
	            res.put("message", "success");
	            res.put("vehicle_id",veh.getVehicle_id());
	            res.put("vehicle_no",veh.getVehicle_no());
	            res.put("vehicle_name",veh.getVehicle_name());
	            res.put("vehicle_model",veh.getVehicle_model());
	            res.put("vehicle_img",veh.getVehicle_img());
	            res.put("noof_seats",veh.getNoof_seats());
	            res.put("rate_perkm",veh.getRate_perkm());
	            res.put("vehicle_booked",veh.isVehicle_booked());
	            res.put("otherproperties",veh.getOtherproperties());
	    	}
	    	catch (Exception e) {
	    		res.put("responsecode", 0);
	            res.put("message", "failed");
	            System.out.println("failed" + e);
	        
	    	}
	    	return res.toString();
	    }
	    @RequestMapping(value = "/vehicle/view/all", method = RequestMethod.GET)  
	    public @ResponseBody
	    	String vehicleviewall() {
	    	JSONObject response=new JSONObject();
	    	JSONArray arr=new JSONArray();
	    	try {
	    		List<Vehicle> vehicle=dao.viewAll();
	    		for(Vehicle veh:vehicle) {
	    			JSONObject res = new JSONObject();
		            res.put("vehicle_id",veh.getVehicle_id());
		            res.put("vehicle_no",veh.getVehicle_no());
		            res.put("vehicle_name",veh.getVehicle_name());
		            res.put("vehicle_model",veh.getVehicle_model());
		            res.put("vehicle_img",veh.getVehicle_img());
		            res.put("noof_seats",veh.getNoof_seats());
		            res.put("rate_perkm",veh.getRate_perkm());
		            res.put("vehicle_booked",veh.isVehicle_booked());
		            res.put("otherproperties",veh.getOtherproperties());
		            arr.put(res);
	    		}
	    		response.put("responsecode", 1);
	    		response.put("message", "success");
	    		response.put("vehicle", arr);
	    	}
	    	catch (Exception e) {
	    		response.put("responsecode", 0);
	    		response.put("message", "viewd Faild");
	            System.out.println("failed" + e);
	    	}
	    	return response.toString();
	    }
}