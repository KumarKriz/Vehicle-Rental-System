package com.project.controller;

import java.util.List;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.beans.Reserve;
import com.project.beans.User;
import com.project.dao.*;
@Controller
public class UserController {
    @Autowired
    UsersDao dao;
    @RequestMapping(value = "/user/save", method = RequestMethod.POST)
    public @ResponseBody
    String usersave(@RequestParam(value = "name") String name,
            @RequestParam(value = "email") String email,
            @RequestParam(value = "phno") String phno,
            @RequestParam(value = "age",required=false) int age,
            @RequestParam(value = "address") String address,
            @RequestParam(value = "password") String password,
            @RequestParam(value = "otherproperties",required=false) JSONObject otherproperties) {
        JSONObject res = new JSONObject();
        try {
        	String propStr=null;
        	if(otherproperties.length()>0)
        	{
        		propStr=otherproperties.toString();
        	}
            dao.save(name, email, phno, age, address, password, 0, propStr);
            res.put("responsecode", 1);
            res.put("message", "User Registeration Successfully");
        }
        catch (Exception e) {
            res.put("responsecode", 0);
            res.put("message", "User Registeration failed");
            System.out.println("failed" + e);       
          }
        return res.toString();
    }
    @RequestMapping(value = "/user/login", method = RequestMethod.POST)  
    public @ResponseBody
    	String userlogin(@RequestParam(value = "email") String email,
    			@RequestParam(value = "password") String password) {
    	JSONObject res = new JSONObject();
    	try {
    		User log=dao.login(email, password);
    		res.put("responsecode", 1);
            res.put("message", "login success");
            res.put("userid",log.getUserid());
            res.put("name",log.getName());
            res.put("email",log.getEmail());
            res.put("phno",log.getPhno());
            res.put("age",log.getAge());
            res.put("address",log.getAddress());
            res.put("password",log.getPassword());
            res.put("admin",log.isAdmin());
            res.put("otherproperties",log.getOtherproperties());
    	}
    	catch (Exception e) {
    		res.put("responsecode", 0);
            res.put("message", "User Login Failed");
            System.out.println("failed" + e);
        
    	}
    	return res.toString();     
    }
    
    @RequestMapping(value = "/user/view", method = RequestMethod.POST)  
    public @ResponseBody
    	String userview(@RequestParam(value = "userid") int userid) {
    	JSONObject res = new JSONObject();
    	try {
    		User ser=dao.userview(userid);
    		res.put("responsecode", 1);
            res.put("message", "success");
            res.put("name", ser.getName());
            res.put("email",ser.getEmail());
            res.put("phno",ser.getPhno());
            res.put("age",ser.getAge());
            res.put("address",ser.getAddress());
            res.put("password",ser.getPassword());
            res.put("otherproperties",ser.getOtherproperties());
    	}
    	catch (Exception e) {
    		res.put("responsecode", 0);
            res.put("message", "failed");
            System.out.println("failed" + e);        
    	}
    	return res.toString();
    }
    
    @RequestMapping(value = "/user/edit", method = RequestMethod.POST)
    public @ResponseBody
    String useredit(@RequestParam(value = "userid") int userid,
    		@RequestParam(value = "name",required=false) String name,
            @RequestParam(value = "email",required=false) String email,
            @RequestParam(value = "phno",required=false) String phno,
            @RequestParam(value = "age",required=false) int age,
            @RequestParam(value = "address",required=false) String address,
            @RequestParam(value = "password",required=false) String password,
            @RequestParam(value = "otherproperties",required=false) String otherproperties) {
        JSONObject res = new JSONObject();
        try {
        	String propStr=null;
        	if(otherproperties.length()>0)
        	{
        		propStr=otherproperties.toString();
        	}
            dao.edit(userid, name, email, phno, age, address, password, propStr);
            res.put("responsecode", 1);
            res.put("message", "user edited Successfully");
        } catch (Exception e) {
            res.put("responsecode", 0);
            res.put("message", "User edited failed");
        }
        return res.toString();
    }  
}
