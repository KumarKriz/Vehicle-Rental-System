package com.project.controller;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.beans.Reserve;
import com.project.dao.UsersDao;

@Controller
public class ReserveController {
	@Autowired
    UsersDao dao;
    @RequestMapping(value = "/reserve/make", method = RequestMethod.POST)
    public @ResponseBody
    String reservemake(@RequestParam(value = "userid") int userid,
    		@RequestParam(value = "vehicle_id") int vehicle_id,
    		@RequestParam(value = "pickup_loc") String pickup_loc,
            @RequestParam(value = "drop_loc") String drop_loc,
            @RequestParam(value = "start_meter",required=false,defaultValue="0") double start_meter,
            @RequestParam(value = "end_meter",required=false,defaultValue="0") double end_meter,
            @RequestParam(value = "days") int days,
            @RequestParam(value = "advance") double advance,
            @RequestParam(value = "amount",required=false,defaultValue="0") double amount,
            @RequestParam(value = "otherproperties",required=false) String otherproperties,
            @RequestParam(value = "reserve_date") double reserve_date) {
    JSONObject res = new JSONObject();
    try {
    	String propStr=null;
    	if(otherproperties.length()>0)
    	{
    		propStr=otherproperties.toString();
    	}
    	dao.make(userid, vehicle_id, pickup_loc, drop_loc, start_meter, end_meter, days, advance, amount, propStr, 0, reserve_date);
        dao.updateBookedVehicle(1, vehicle_id);
    	res.put("responcecode", 1);
    	res.put("message", "reservation succesfully");
    }
    catch (Exception e)
    {
      	res.put("responcecode", 0);
    	res.put("message", "reservation failed");
    	System.out.println("failed" + e);
    }
    return res.toString();
    }
    
    @RequestMapping(value = "/reserve/update", method = RequestMethod.POST)
    public @ResponseBody
    String reserveupdate(@RequestParam(value = "reservation_id") int reservation_id,
    		@RequestParam(value = "vehicle_id") int vehicle_id,
    		@RequestParam(value = "pickup_loc",required=false) String pickup_loc,
            @RequestParam(value = "drop_loc",required=false) String drop_loc,
            @RequestParam(value = "start_meter",required=false,defaultValue="0") double start_meter,
            @RequestParam(value = "end_meter",required=false,defaultValue="0") double end_meter,
            @RequestParam(value = "days",required=false) int days,
            @RequestParam(value = "advance",required=false) double advance,
            @RequestParam(value = "amount",required=false,defaultValue="0") double amount,
            @RequestParam(value = "otherproperties",required=false) String otherproperties,
            @RequestParam(value = "reserve_date") double reserve_date) {
    	JSONObject res = new JSONObject();
    	try {
    		String propStr=null;
        	if(otherproperties.length()>0)
        	{
        		propStr=otherproperties.toString();
        	}
    		  dao.update(reservation_id, vehicle_id, pickup_loc, drop_loc, start_meter, end_meter, days, advance, amount, propStr, reserve_date);
              res.put("responsecode", 1);
              res.put("message", "reservation edited Successfully");
    	}
    	catch(Exception e) {
              res.put("responsecode", 0);
              res.put("message", "reservation edited failed");
              System.out.println("reservation edited failed" + e);
    	}
    	return res.toString();
}
    @RequestMapping(value = "/reserve/remove", method = RequestMethod.POST)
    public @ResponseBody
    String reserveremove(@RequestParam(value = "reservation_id") int reservation_id) {
    	JSONObject res = new JSONObject();
    	try {
    		  dao.remove(reservation_id);
              res.put("responsecode", 1);
              res.put("message", "reservation canceled Successfully");
    	}
    	catch(Exception e) {
              res.put("responsecode", 0);
              res.put("message", "reservation cancel failed");
              System.out.println("failed" + e);
    	}
    	return res.toString();
    }
    
    @RequestMapping(value = "/reserve/resview", method = RequestMethod.POST)  
    public @ResponseBody
    	String reserveresview(@RequestParam(value = "reservation_id") int reservation_id) {
    	JSONObject res = new JSONObject();
    	try {
    		Reserve ser=dao.resview(reservation_id);
    		res.put("responsecode", 1);
            res.put("message", "success");
            res.put("userid", ser.getUserid());
            res.put("vehicle_id", ser.getVehicle_id());
            res.put("reservation_id",ser.getReservation_id());
            res.put("pickup_loc",ser.getPickup_loc());
            res.put("drop_loc",ser.getDrop_loc());
            res.put("start_meter",ser.getStart_meter());
            res.put("end_meter",ser.getEnd_meter());
            res.put("days",ser.getDays());
            res.put("advance",ser.getAdvance());
            res.put("amount",ser.getAmount());
            res.put("otherproperties",ser.getOtherproperties());
            res.put("returned",ser.isReturned());
            res.put("reserve_date",ser.getReserve_date());
    	}
    	catch (Exception e) {
    		res.put("responsecode", 0);
            res.put("message", "failed");
            System.out.println("failed" + e);        
    	}
    	return res.toString();
    }
    @RequestMapping(value = "/reserve/returnvehicle", method = RequestMethod.POST)
    public @ResponseBody
    String reserveReturnVehicle(@RequestParam(value = "vehicle_id") int vehicle_id,
    		@RequestParam(value = "reservation_id") int reservation_id,
            @RequestParam(value = "amount") double amount,
            @RequestParam(value = "start_meter") double start_meter,
            @RequestParam(value = "end_meter") double end_meter) {
    	JSONObject res = new JSONObject();
    	try {
    		  dao.returnVehicle(amount, reservation_id, 1, start_meter, end_meter);
    		  dao.updateBookedVehicle(0, vehicle_id);
              res.put("responsecode", 1);
              res.put("message", "vehicle returned Successfully");
    	}
    	catch(Exception e) {
              res.put("responsecode", 0);
              res.put("message", "vehicle returned failed");
              System.out.println("failed" + e);
    	}
    	return res.toString();
}
    
    @RequestMapping(value = "/reserve/view/resall", method = RequestMethod.GET)  
    public @ResponseBody
    	String reserveviewresall() {
    	JSONObject response=new JSONObject();
    	JSONArray arr=new JSONArray();
    	try {
    		List<Reserve> reserve=dao.viewResAll();
    		for(Reserve veh:reserve) {
    			JSONObject res = new JSONObject();
	            res.put("userid",veh.getUserid());
	            res.put("vehicle_id",veh.getVehicle_id());
	            res.put("reservation_id",veh.getReservation_id());
	            res.put("pickup_loc",veh.getPickup_loc());
	            res.put("drop_loc",veh.getDrop_loc());
	            res.put("start_meter",veh.getStart_meter());
	            res.put("end_meter",veh.getEnd_meter());
	            res.put("days",veh.getDays());
	            res.put("advance",veh.getAdvance());
	            res.put("amount",veh.getAmount());
	            res.put("otherproperties",veh.getOtherproperties());
	            res.put("returned",veh.isReturned());
	            res.put("reserve_date",veh.getReserve_date());
	            arr.put(res);
    		}
    		response.put("responsecode", 1);
    		response.put("message", "success");
    		response.put("reserve", arr);
    	}
    	catch (Exception e) {
    		response.put("responsecode", 0);
    		response.put("message", "viewd Faild");
            System.out.println("failed" + e);
    	}
    	return response.toString();
    }
    

    @RequestMapping(value = "/reserve/view/userbyid", method = RequestMethod.GET)  
    public @ResponseBody
    	String reserveviewuserbyid(@RequestParam(value = "userid") int userid) {
    	JSONObject response=new JSONObject();
    	JSONArray arr=new JSONArray();
    	try {
    		List<Reserve> reserve=dao.resUserViewByUserId(userid);
    		for(Reserve veh:reserve) {
    			JSONObject res = new JSONObject();
	            res.put("userid",veh.getUserid());
	            res.put("vehicle_id",veh.getVehicle_id());
	            res.put("reservation_id",veh.getReservation_id());
	            res.put("pickup_loc",veh.getPickup_loc());
	            res.put("drop_loc",veh.getDrop_loc());
	            res.put("start_meter",veh.getStart_meter());
	            res.put("end_meter",veh.getEnd_meter());
	            res.put("days",veh.getDays());
	            res.put("advance",veh.getAdvance());
	            res.put("amount",veh.getAmount());
	            res.put("otherproperties",veh.getOtherproperties());
	            res.put("returned",veh.isReturned());
	            res.put("reserve_date",veh.getReserve_date());
	            arr.put(res);
    		}
    		response.put("responsecode", 1);
    		response.put("message", "success");
    		response.put("reserve", arr);
    	}
    	catch (Exception e) {
    		response.put("responsecode", 0);
    		response.put("message", "reservation viwe by userid Faild");
            System.out.println("failed" + e);
    	}
    	return response.toString();
    }
}