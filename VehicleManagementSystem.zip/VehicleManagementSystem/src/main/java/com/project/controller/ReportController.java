package com.project.controller;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.project.beans.Reserve;
import com.project.beans.User;
import com.project.beans.Vehicle;
import com.project.dao.UsersDao;


@Controller
public class ReportController {
    @Autowired
    UsersDao dao;

@RequestMapping(value = "/reserve/view/report", method = RequestMethod.GET)  
public @ResponseBody
	String reserveviewreport(@RequestParam(value = "start") long start,
			                 @RequestParam(value = "end") long end) {
	JSONObject response=new JSONObject();
	JSONArray arr=new JSONArray();
	try {
		List<Reserve> reserve=dao.viewReport(start, end);
		double total=0;
		for(Reserve veh:reserve) {
			JSONObject res = new JSONObject();
			int userid = veh.getUserid();
			User ser=dao.userview(userid);
            res.put("name", ser.getName());
            res.put("email",ser.getEmail());
            res.put("phno",ser.getPhno());
            res.put("age",ser.getAge());
            res.put("address",ser.getAddress());
            
            
            int veh_id=veh.getVehicle_id();
            res.put("vehicle_id",veh_id);
            Vehicle vehi=dao.view(veh_id);
            res.put("vehicle_no",vehi.getVehicle_no());
            res.put("vehicle_name",vehi.getVehicle_name());
            res.put("vehicle_model",vehi.getVehicle_model());
            res.put("vehicle_img",vehi.getVehicle_img());
            res.put("noof_seats",vehi.getNoof_seats());
            res.put("rate_perkm",vehi.getRate_perkm());
            res.put("vehicle_booked",vehi.isVehicle_booked());
            
            
            res.put("reservation_id",veh.getReservation_id());
            res.put("pickup_loc",veh.getPickup_loc());
            res.put("drop_loc",veh.getDrop_loc());
            res.put("start_meter",veh.getStart_meter());
            res.put("end_meter",veh.getEnd_meter());
            res.put("days",veh.getDays());
            res.put("advance",veh.getAdvance());
            double amount = veh.getAmount();
            total+= amount;
            res.put("amount",amount);
            res.put("otherproperties",veh.getOtherproperties());
            res.put("returned",veh.isReturned());
            arr.put(res);
		}
		response.put("responsecode", 1);
		response.put("message", "success");
	    response.put("reserve", arr);
	    response.put("total", total);
	}
	catch (Exception e) {
		response.put("responsecode", 0);
		response.put("message", "viewd Faild");
        System.out.println("failed" + e);
	}
	return response.toString();
}



}




