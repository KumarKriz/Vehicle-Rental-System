$(document).ready(function(){
    var userid = localStorage.getItem("userid");
    var settings = {
  "url": "http://localhost:8080/vehiclesystem/user/view",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "userid": userid
  }
};
        
$.ajax(settings).done(function (response){
    console.log(response);
    if(response!=null){
        var resjson = JSON.parse(response);
        if(resjson.responsecode==1){
            if(resjson.name!=null){
                $("#name").val(resjson.name);
            }
            if(resjson.email!=null){
                $("#email").val(resjson.email);
            }
            if(resjson.phno!=null){
                $("#phno").val(resjson.phno);
            }
            if(resjson.age!=null){
                $("#age").val(resjson.age);
            }
            if(resjson.address!=null){
                $("#address").val(resjson.address);
            }
            if(resjson.password!=null){
                $("#password").val(resjson.password);
            }
            var otherresjson = resjson.otherproperties;
            if(otherresjson!=null){
             if(otherresjson.adhaar!=null){
                 $("#card").val(otherresjson.adhaar);
             }   
            }
        }
    }
});
    
    $("#useredit").click(function() {
        
        var name = $("#name").val();
        var email = $("#email").val();
        var phno = $("#phno").val();
        var age  = $("#age").val();
        var address = $("#address").val();
        var password = $("#password").val();
        var adhaar = $("#card").val();
        var otherproperties='{"adhaar":'+adhaar+'}';

var settings = {
  "url": "http://localhost:8080/vehiclesystem/user/edit",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "userid": userid,
    "name": name,
    "email": email,
    "phno": phno,
    "age": age,
    "address": address,
    "password": password,
    "otherproperties": otherproperties
  }
};

$.ajax(settings).done(function (response) {
  console.log(response);
    window.alert("User Edited Sucessfully");
    window.location="user.html";
});
});
});