function getQueryParam(param) {
    var queryString = {};
    location.search.substr(1).split("&").forEach(function(pair) {
        if (pair === "")
            return;
        var parts = pair.split("=");
        queryString[parts[0]] = parts[1] && decodeURIComponent(parts[1].replace(/\+/g, " "));
    });
    return queryString && queryString[param] || "";
};
$( window ).on( "load", getQueryParam);



$(document).ready(function(){
    var vehicle_id = getQueryParam("vehicle_id");
var settings = {
  "url": "http://localhost:8080/vehiclesystem/vehicle/delete",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "vehicle_id": vehicle_id
  }
};

$.ajax(settings).done(function (response) {
  console.log(response);
    var resjson = JSON.parse(response);
    localStorage.setItem("vehicle_id",resjson.vehicle_id)
    if(resjson.responsecode==1){
        window.location="vehicledetails.html";
        window.alert("Are you sure to delete this vehicle");
    }
    else{
        alert(resjson.message);
    }
});
});
