$(document).ready(function(){
    $("#vehadd").click(function() {
        
        var vehicle_no = $("#vnumber").val();
        var vehicle_name = $("#vname").val();
        var vehicle_model = $("#vmodel").val();
        var vehicle_img  = $("#img").val();
        var noof_seats = $("#seats").val();
        var rate_perkm = $("#rate").val();
        var veh_added_date = $("#added").val();
        var otherproperties='{"veh_added_date":'+veh_added_date+'}';

var settings = {
  "url": "http://localhost:8080/vehiclesystem/vehicle/add",
  "method": "POST",
    cors: true ,
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "vehicle_no": vehicle_no,
    "vehicle_name": vehicle_name,
    "vehicle_model": vehicle_model,
    "vehicle_img": vehicle_img,
    "noof_seats": noof_seats,
    "rate_perkm": rate_perkm,
    "otherproperties": otherproperties
  }
};

$.ajax(settings).done(function (response) {
    var resjson=JSON.parse(response);
    if(resjson.responsecode==1){
        alert(resjson.message);
        window.location="vehicledetails.html";
    }
    else{
        alert(resjson.message);
    }
});
        });
    });