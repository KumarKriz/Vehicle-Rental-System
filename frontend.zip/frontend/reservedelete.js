$(document).ready(function(){
    var reserve_id = $("#rid").val();

var settings = {
  "url": "localhost:8080/vehiclesystem/reserve/remove",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "reservation_id": reserve_id
  }
};

$.ajax(settings).done(function (response) {
  console.log(response);
});
});