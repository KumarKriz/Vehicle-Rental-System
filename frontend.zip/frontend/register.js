$(document).ready(function(){
    $("#userregister").click(function() {
        
        var name = $("#name").val();
        var email = $("#email").val();
        var phno = $("#phno").val();
        var age  = $("#age").val();
        var address = $("#address").val();
        var password = $("#password").val();
        var adhaar = $("#card").val();
        var otherproperties= '{"adhaar":'+adhaar+'}';

var settings = {
  "url": "http://localhost:8080/vehiclesystem/user/save",
  "method": "POST",
    cors: true ,
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "name": name,
    "email": email,
    "phno": phno,
    "age": age,
    "address": address,
    "password": password,
    "otherproperties": otherproperties
  }
};
$.ajax(settings).done(function (response) {
    var resjson=JSON.parse(response);
    if(resjson.responsecode==1){
        alert(resjson.message);
        window.location="login.html";
    }
    else{
        alert(resjson.message);
    }
});
    
});
});