function getQueryParam(param) {
    var queryString = {};
    location.search.substr(1).split("&").forEach(function(pair) {
        if (pair === "")
            return;
        var parts = pair.split("=");
        queryString[parts[0]] = parts[1] && decodeURIComponent(parts[1].replace(/\+/g, " "));
    });
    return queryString && queryString[param] || "";
};
$( window ).on( "load", getQueryParam);



$(document).ready(function(){
    var userid = getQueryParam("userid");
    var vehicle_id = getQueryParam("vehicle_id");
    $("#resadd").click(function(){
        var pickup_loc = $("#ploc").val();
        var drop_loc  = $("#dloc").val();
        var days =$("#days").val();
        var advance = $("#adv").val();
        var lic_id = $("#lic_id").val();
        var otherproperties= '{"lic_id":'+lic_id+'}';
        var reserve_date = $("#bdate").val();
        var d=new Date(reserve_date);
        var ep_date = d.valueOf();

var settings = {
  "url": "http://localhost:8080/vehiclesystem/reserve/make",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "userid": userid,
    "vehicle_id": vehicle_id,
    "pickup_loc": pickup_loc,
    "drop_loc": drop_loc,
    "days": days,
    "advance": advance,
    "otherproperties": otherproperties,
    "reserve_date": ep_date
  }
};

$.ajax(settings).done(function (response) {
  console.log(response);
    var resjson = JSON.parse(response);
    if(resjson.responsecode==1){
        alert(resjson.message);
        var isadmin = localStorage.getItem("admin")=="true";
        if(isadmin){
        window.location="reservedetails.html";
        }
        else{
            window.location="makeres.html"
        }
    }
    else{
        alert(resjson.message);
    }
});
    });
});