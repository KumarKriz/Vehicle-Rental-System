function getQueryParam(param) {
    var queryString = {};
    location.search.substr(1).split("&").forEach(function(pair) {
        if (pair === "")
            return;
        var parts = pair.split("=");
        queryString[parts[0]] = parts[1] && decodeURIComponent(parts[1].replace(/\+/g, " "));
    });
    return queryString && queryString[param] || "";
};
$( window ).on( "load", getQueryParam);




$(document).ready(function (){
    var vehicle_id = null; 
     var reservation_id = getQueryParam("reservation_id");
    
    var settings = {
  "url": "http://localhost:8080/vehiclesystem/reserve/resview",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "reservation_id": reservation_id
  }
};

$.ajax(settings).done(function (response) {
  console.log(response);
    if(response!=null){
        var resjson = JSON.parse(response);
        if(resjson.responsecode==1){
            if(resjson.vehicle_id!=null){
                vehicle_id = resjson.vehicle_id;
            }
            if(resjson.days!=null){
                $("#days").val(resjson.days);
            }
            if(resjson.advance!=null){
                $("#adv").val(resjson.advance);
            }
            if(resjson.amount>0){
                $("#amo").val(resjson.amount);
            }
        }
    }
});

    
    
    $("#calculate").click(function (){
        var s_meter = $("#smeter").val();
        var e_meter = $("#emeter").val();
        var days = $("#days").val();
        var rate_perkm = $("#rate").val();
        var advance = $("#adv").val();
        var distance = e_meter-s_meter;
        var total = distance*rate_perkm+(days*500);
        var balance = total-advance;
        $("#amo").val(total);
        $("#bal").val(balance);
    
    });
    
    
$("#return").click(function (){    

var amo = $("#amo").val();
var s_meter = $("#smeter").val();
var e_meter = $("#emeter").val();

var settings = {
  "url": "http://localhost:8080/vehiclesystem/reserve/returnvehicle",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "vehicle_id": vehicle_id,
    "reservation_id": reservation_id,
    "amount": amo,
    "start_meter": s_meter,
    "end_meter": e_meter
  }
};

$.ajax(settings).done(function (response) {
    window.location="reservedetails.html";
  console.log(response);
});
});
});