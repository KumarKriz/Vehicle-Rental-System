$(document).ready(function(){
    $("#generate").click(function(){
        $("#tableid").remove();
    
        var start = $("#sdate").val();
        var d=new Date(start);
        var ep_date = d.valueOf();
        var end = $("#edate").val();
        var d=new Date(end);
        var ep_date2 = d.valueOf();

var settings = {
  "url": "http://localhost:8080/vehiclesystem/reserve/view/report?start="+ep_date+"&end="+ep_date2,
  "method": "GET",
  "timeout": 0,
};


$.ajax(settings).done(function (response) {
  console.log(response);
    if(response!=null){
        var resjson = JSON.parse(response);
        if(resjson.responsecode==1){
            var reserve = resjson && resjson.reserve;
            var reslen = reserve.length;
            var table = "<table id='tableid'>";
            var th = "<th>Days</th><th>Amount</th><th>Name</th><th>Email</th><th>Pickup location</th><th>Drop location</th><th>Vehicle no</th><th>Vehicle Name</th>";
            table += th;
            for(var i=0; i<reslen; i++){
                var getresjson = reserve[i];
                var tr = "<tr>";
                if(getresjson.days!=null){
                    var td = "<td>";
                    td += getresjson.days;
                    td += "</td>";
                    tr += td;
                }
                if(getresjson.amount!=null){
                    var td = "<td>";
                    td += getresjson.amount;
                    td += "</td>";
                    tr += td;
                }
                if(getresjson.name!=null){
                    var td = "<td>";
                    td +=getresjson.name;
                    td += "</td>";
                    tr += td;
                }
                if(getresjson.email!=null){
                    var td = "<td>";
                    td += getresjson.email;
                    td += "</td>";
                    tr += td;
                }
                if(getresjson.pickup_loc!=null){
                    var td = "<td>";
                    td += getresjson.pickup_loc;
                    td += "</td>";
                    tr += td;
                }
                if(getresjson.drop_loc!=null){
                    var td = "<td>";
                    td += getresjson.drop_loc;
                    td += "</td>";
                    tr += td;
                }
                if(getresjson.vehicle_no!=null){
                    var td = "<td>";
                    td += getresjson.vehicle_no;
                    td += "</td>";
                    tr += td;
                }
                if(getresjson.vehicle_name!=null){
                    var td = "<td>";
                    td += getresjson.vehicle_name;
                    td += "</td>";
                    tr += td;
                }
                
                tr += "</tr>";
                table += tr;
            }
        
                if(resjson.total!=null){
                    var tr = "<tr>";
                    var td = "<td>Total</td><td>";
                    td += resjson.total;
                    td += "</td>";
                    tr += td;
                    tr += "</tr>";
                    table += tr;
                }
        
            table += "</table>";
            $("#report").append(table);
            
        }
    }
});
    });
});