$(document).ready(function(){
           localStorage.removeItem("admin");
          localStorage.removeItem("userid");
    
    $("#login").click(function() {
        
        
        var username = $("#username").val();
        var password = $("#password").val();
     
  var settings = {
  "url": "http://localhost:8080/vehiclesystem/user/login",
  "method": "POST",
  "timeout": 1000,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "email": username,
    "password": password
  }
};
        
        

$.ajax(settings).done(function (response){
    if(response!=null){
        var resjson=JSON.parse(response);
        if(resjson.responsecode==1)
            {
                localStorage.setItem("userid",resjson.userid);
                if(resjson.admin){
                    localStorage.setItem("admin",true);
                    window.location="admin.html";
                }
                else{
                    window.location="user.html";
                }
            }
        else{
            alert(resjson.message);
        }
    }
    else{
        alert("invaild");
    }
    
            
});  
    
});
  
});