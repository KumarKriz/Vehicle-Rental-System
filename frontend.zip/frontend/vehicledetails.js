$(document).ready(function(){
   var settings = {
  "url": "http://localhost:8080/vehiclesystem/vehicle/view/all",
  "method": "GET",
  "timeout": 0,
};
    
$.ajax(settings).done(function (response) {
  console.log(response);
    if(response!=null){
        var vehjson = JSON.parse(response);
        if(vehjson.responsecode==1){
            var vehicle = vehjson && vehjson.vehicle;
            var vehlen = vehicle.length;
            var table = "<table>";
            var th = "<th>Vehicle Images</th><th>Vehicle No</th><th>Vehicle Name</th><th>Vehicle Model</th><th>No Of Seats</th><th>Rate Per Km</th>";
            table += th;
            for(var i=0; i<vehlen; i++){
                var getvehjson = vehicle[i];
                var tr = "<tr id='"+getvehjson.vehicle_id+"'>";
                if(getvehjson.vehicle_img!=null){
                     var td ="<td>"; 
                     td += '<img src="'+getvehjson.vehicle_img+'" alt="no image" width="450" height="500">';
                    td +="</td>";
                    tr += td;
                   }
                if(getvehjson.vehicle_no!=null){
                      var td = "<td>";
                    td +=getvehjson.vehicle_no;
                      td +="</td>";
                      tr += td;
                   }
                if(getvehjson.vehicle_name!=null){
                      var td = "<td>";
                    td +=getvehjson.vehicle_name;
                      td +="</td>";
                      tr += td;
                   }
                if(getvehjson.vehicle_model!=null){
                    var td = "<td>";
                  td +=getvehjson.vehicle_model;
                    td +="</td>";
                    tr += td;
                }
                if(getvehjson.noof_seats!=null){
                    var td = "<td>";
                    td +=getvehjson.noof_seats;
                    td +="</td>";
                    tr += td;
                }
                if(getvehjson.rate_perkm!=null){
                    var td = "<td>";
                    td +=getvehjson.rate_perkm;
                    td +="</td>";
                    tr += td;
                }    
                
                tr += '<td><a href="vehicleedit.html?vehicle_id='+getvehjson.vehicle_id+'"><i class="fa fa-edit" aria-hidden="true"></i>Edit</a></td> <td><a href="vehicleedit.html?delete=true&vehicle_id='+getvehjson.vehicle_id+'"><i class="fa fa-trash" aria-hidden="true"></i>Delete</a></td>';
                
                tr +="</tr>";
                table += tr;
            }
            
    table += "</table>";
    $("#veh_view").append(table);
        }
    }
    
});
});

    