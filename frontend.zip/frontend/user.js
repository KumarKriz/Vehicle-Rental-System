$(document).ready(function(){
   $("#logout").click(function (){
       if(admin==1){
           localStorage.removeItem("admin");
       }
       else{
        localStorage.removeItem("userid");   
       }
           window.location="login.html";
   });;
});