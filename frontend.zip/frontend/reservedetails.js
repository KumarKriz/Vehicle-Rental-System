$(document).ready(function(){
    var url;
    var isadmin = localStorage.getItem("admin")=="true";
    if(isadmin){
        url = "http://localhost:8080/vehiclesystem/reserve/view/resall";
    }
    else{
        var userid = localStorage.getItem("userid");
        url = "http://localhost:8080/vehiclesystem/reserve/view/userbyid?userid="+userid; 
    }
var settings = {
  "url": url,
  "method": "GET",
  "timeout": 0,
};

$.ajax(settings).done(function (response) {
  console.log(response);
    if(response!=null){
        var resjson = JSON.parse(response);
        if(resjson.responsecode==1){
            var reserve = resjson && resjson.reserve;
            var reslen = reserve.length;
            var table = "<table>";
            var th = "<th>Pickup Location</th><th>Drop Location</th><th>Start Meter</th><th>End Meter</th><th>Days</th><th>Advance</th><th>Amount</th><th>Licansce Number</th><th>Reservation Date</th>";
            table += th;
            for(var i=0; i<reslen; i++){
                var getresjson = reserve[i];
                var tr = "<tr>";
                if(getresjson.pickup_loc!=null){
                      var td = "<td>";
                      td +=getresjson.pickup_loc;
                      td +="</td>";
                      tr += td;
                   }
                if(getresjson.drop_loc!=null){
                    var td = "<td>";
                  td +=getresjson.drop_loc;
                    td +="</td>";
                    tr += td;
                }
                if(getresjson.start_meter!=null){
                    var td = "<td>";
                    td +=getresjson.start_meter;
                    td +="</td>";
                    tr += td;
                }
                if(getresjson.end_meter!=null){
                    var td = "<td>";
                    td +=getresjson.end_meter;
                    td +="</td>";
                    tr += td;
                }
                if(getresjson.days!=null){
                    var td = "<td>";
                    td +=getresjson.days;
                    td +="</td>";
                    tr += td;
                }
                if(getresjson.advance!=null){
                    var td = "<td>";
                    td +=getresjson.advance;
                    td +="</td>";
                    tr += td;
                }
                if(getresjson.amount!=null){
                    var td = "<td>";
                    td +=getresjson.amount;
                    td +="</td>";
                    tr += td;
                }
                var otherjson = getresjson.otherproperties;
                if(otherjson!=null){
                 if(otherjson.lic_id!=null){
                    var td = "<td>";
                    td +=otherjson.lic_id;
                    td +="</td>";
                    tr += td;
                }   
                }
                var ep_date=0;
                if(getresjson.reserve_date!=null){
                    ep_date = getresjson.reserve_date;
                    var ep_to_date = new Date(ep_date).toLocaleDateString();
                    var td = "<td>";					
                    td +=ep_to_date;
                    td +="</td>";
                    tr += td;
                }
       
                
                var td = "<td>&nbsp &nbsp";
                td += '<a href="reserveupdate.html?reservation_id='+getresjson.reservation_id+'"><i class="fa fa-edit" aria-hidden="true"></i></a> <a href="reserveupdate.html?delete=true&reservation_id='+getresjson.reservation_id+'"><i class="fa fa-trash" aria-hidden="true"></i></a>'; 
                if(isadmin==true){
                    var cur_ep_date = new Date().valueOf();
                if(ep_date<cur_ep_date){
                    td +=' <a href="return.html?reservation_id='+getresjson.reservation_id+'">Return</a>';
                }
                }
                td +='</td>';
                tr += td;
                
                tr +="</tr>";
                table += tr;
            }
            
    table += "</table>";
            console.log(table);
    $("#resdetails").append(table);
        }
    }
});
});