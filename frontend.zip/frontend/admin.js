$(document).ready(function(){
   $("#logout").click(function (){
         localStorage.removeItem("admin");
          localStorage.removeItem("userid");
           window.location="login.html";  
   });
})