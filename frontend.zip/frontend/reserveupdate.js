function getQueryParam(param) {
    var queryString = {};
    location.search.substr(1).split("&").forEach(function(pair) {
        if (pair === "")
            return;
        var parts = pair.split("=");
        queryString[parts[0]] = parts[1] && decodeURIComponent(parts[1].replace(/\+/g, " "));
    });
    return queryString && queryString[param] || "";
};
$( window ).on( "load", getQueryParam);


$(document).ready(function(){
    var reservation_id = getQueryParam("reservation_id");
    var vehicle_id;
    var reserve_date,otherproperties;
    var isdelete = getQueryParam("delete")!="";
    if(isdelete){
        $("#resupdate").hide();
        $("#resdelete").show();
    }
    else{
        $("#resdelete").hide();
        $("#resupdate").show();
    }
    var settings = {
  "url": "http://localhost:8080/vehiclesystem/reserve/resview",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "reservation_id": reservation_id
  }
};

$.ajax(settings).done(function (response) {
    if(response!=null){
        var resjson = JSON.parse(response);
        if(resjson.responsecode==1){
            if(resjson.pickup_loc!=null){
                $("#ploc").val(resjson.pickup_loc);
            }
            if(resjson.drop_loc!=null){
                $("#dloc").val(resjson.drop_loc);
            }
            if(resjson.days){
                $("#days").val(resjson.days);
            }
            if(resjson.advance){
                $("#adv").val(resjson.advance);
            }
            if(resjson.vehicle_id){
                vehicle_id = resjson.vehicle_id;
            }
            if(resjson.reserve_date){
                reserve_date = resjson.reserve_date;
            }
            if(resjson.otherproperties){
                otherproperties = resjson.otherproperties;
            }
          
            
        }
    }
});
    
    $("#resdelete").click(function() {
    window.alert("Are you sure to cancel the reversation");

var settings = {
  "url": "http://localhost:8080/vehiclesystem/reserve/remove",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "reservation_id": reservation_id
  }
};

$.ajax(settings).done(function (response) {
  console.log(response);
    var resjson = JSON.parse(response);
    localStorage.setItem("reservation_id",resjson.reservation_id)
    if(resjson.responsecode==1){
        window.location="reservedetails.html";
    }
    else{
        alert(resjson.message);
    }
    
});
});
    
    $("#resupdate").click(function() {
        var pickup_loc = $("#ploc").val();
        var drop_loc  = $("#dloc").val();
        var days =$("#days").val();
        var advance = $("#adv").val();

var settings = {
  "url": "http://localhost:8080/vehiclesystem/reserve/update",
  "method": "POST",
  "timeout": 0,
  "headers": {
    "Content-Type": "application/x-www-form-urlencoded"
  },
  "data": {
    "vehicle_id": vehicle_id,
    "reservation_id": reservation_id,
    "pickup_loc": pickup_loc,
    "drop_loc": drop_loc,
    "days": days,
    "advance": advance,
    "reserve_date": reserve_date,
    "otherproperties":JSON.stringify(otherproperties)
  }
};

$.ajax(settings).done(function (response) {
  console.log(response);
    var resjson = JSON.parse(response);
    if(resjson.responsecode==1){
        window.location="reservedetails.html";
    }
    else{
        alert(resjson.message);
    }
});
    });
});